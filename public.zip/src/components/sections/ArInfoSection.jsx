import React from "react";

const ArInfoSection = (props) => {
  return (
    <div className="flex flex-col gap-8 items-center">
      <div
        className={`text-[30px] font-bold flex flex-col justify-center items-center ${props.titleClassName}`}
      >
        <span>{props.title}</span>
        <span className="text-sm font-light">{props.subTitle}</span>
      </div>
      <div className={`flex gap-8 items-center ${props.boxClassName}`}>
        <ul className="flex flex-col gap-4">
          {props.Texts.map((item) => (
            <li className="flex items-center gap-2">
              <span className={props.iconClassName}>{item.icon}</span>
              <span className={props.textClassName}>{item.text}</span>
            </li>
          ))}
        </ul>
        <div
          className={`flex items-center justify-center ${props.contentClassName}`}
        >
          {props.content}
        </div>
      </div>
    </div>
  );
};

export default ArInfoSection;
