import { Container, Typography } from "@mui/material";
import React from "react";
import ArContainer from "../../layout/ArContainer";

const ArHeader = () => {
  return (
    <div>
      <ArContainer>
        <Typography
          variant="h2"
          sx={{ fontSize: "2.2rem", fontWeight: "700" }}
          gutterBottom
        >
          For<span className="text-[#ffc300]"> Manufacturers</span> ,<br />{" "}
          Service providers and Distributors.
        </Typography>
      </ArContainer>
      
    </div>
  );
};

export default ArHeader;
