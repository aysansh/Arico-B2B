import { AppBar, Box, Link } from "@mui/material";
import Container from "@mui/material/Container";
import Toolbar from "@mui/material/Toolbar";
import React from "react";
import LogoImg from "../../assets/ARICO-B2B-EPS.svg";

const ArNavBarDesktop = () => {
  const [anchorElNav, setAnchorElNav] = React.useState(null);
  const [anchorElUser, setAnchorElUser] = React.useState(null);

  const handleOpenNavMenu = (event) => {
    setAnchorElNav(event.currentTarget);
  };

  return (
    <AppBar position="sticky" sx={{ backgroundColor: "white", p: 0 }}>
      <Container
        sx={{
          padding: 0,
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          // height: "50px",
        }}
        maxWidth="540px"
      >
        <Toolbar
          sx={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
            width: "100%",
            color: "black",
            flexGrow: 2,
          }}
        >
          <Box
            sx={{ height: "30px", backgroundColor: "#ffc602", width: "100%",display: "flex",gap:'2rem' }}
          >
            <Link href="#" sx={{ textDecoration:'none',color:'black'}}>
              About Us
            </Link>
            <Link href="#" sx={{ textDecoration:'none',color:'black'}}>
              Contact
            </Link>
          </Box>
          <Box sx={{ height: "53px",width:'100%' ,display: "flex", gap:'2rem' }}>
            <Link sx={{ textDecoration:'none',color:'black'}} href="#">
              Prelunch
            </Link>
            <Link sx={{ textDecoration:'none',color:'black'}} href="#">
              Pricing
            </Link>
            <Link sx={{ textDecoration:'none',color:'black'}} href="#">
              FQA
            </Link>
          </Box>
        </Toolbar>
        <Toolbar
          sx={{
            display: "flex",
            justifyContent: "center",
            color: "black",
            flexGrow: 1,
          }}
        >
          {/* LogoImg desktop*/}
          <Link
            href="#"
            sx={{
              mr: 2,
              display: { xs: "none", md: "flex" },
              width: "100px",
              height: "fit",
            }}
          >
            <img src={LogoImg} width={"100%"} />
          </Link>
        </Toolbar>
        <Toolbar
          sx={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
            width: "100%",
            color: "black",
            flexGrow: 2,
          }}
        >
          <Box
            sx={{ height: "30px", backgroundColor: "#333", width: "100%" ,display: "flex", justifyContent: "flex-end",gap:'2rem' }}
          >
            <Link href="#" sx={{ textDecoration:'none',color:'white'}}>
              About Us
            </Link>
            <Link href="#" sx={{ textDecoration:'none',color:'white'}}>
              Contact
            </Link>
          </Box>
          <Box sx={{ height: "53px",width:'100%' ,display: "flex", justifyContent:'flex-end',gap:'2rem' }}>
            <Link
          sx={{ textDecoration:'none',color:'black'}}
             href="#">
              Prelunch
            </Link>
            <Link
          sx={{ textDecoration:'none',color:'black'}}
             href="#">
              Pricing
            </Link>
            <Link sx={{ textDecoration:'none',color:'black'}} href="#">
              FQA
            </Link>
          </Box>
        </Toolbar>
      </Container>
    </AppBar>
  );
};

export default ArNavBarDesktop;
