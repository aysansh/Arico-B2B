import ArHeader from "./components/aricoHeader/ArHeader";
import ArNavBarDesktop from "./components/aricoNav/ArNavBarDesktop";


function App() {
  return (
    <>
      <ArNavBarDesktop />
      <ArHeader/>
    </>
  );
}

export default App;
