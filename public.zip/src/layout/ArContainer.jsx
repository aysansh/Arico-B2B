import React from 'react'

const ArContainer = ({children}) => {
  return (
    <div className='p-8'>
   {children}
    </div>
  )
}

export default ArContainer
