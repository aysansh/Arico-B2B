import React from 'react'
import ArHeader from '../components/aricoHeader/ArHeader'

const HomePage = () => {
  return (
    <>
     <ArHeader/> 
    </>
  )
}

export default HomePage
